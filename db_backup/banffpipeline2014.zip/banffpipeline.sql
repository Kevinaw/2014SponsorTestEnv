-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 13, 2014 at 11:09 PM
-- Server version: 5.5.37
-- PHP Version: 5.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `banffpipeline`
--

-- --------------------------------------------------------

--
-- Table structure for table `2014comments`
--

CREATE TABLE IF NOT EXISTS `2014comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice` int(5) NOT NULL,
  `workgroup` int(3) NOT NULL,
  `comments` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `2014confDetail`
--

CREATE TABLE IF NOT EXISTS `2014confDetail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(10) DEFAULT NULL,
  `funccode` varchar(10) DEFAULT NULL,
  `funcid` int(3) NOT NULL,
  `charged` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8312 ;

--
-- Dumping data for table `2014confDetail`
--

INSERT INTO `2014confDetail` (`id`, `vid`, `funccode`, `funcid`, `charged`) VALUES
(8309, 1973, 'TU1', 35, '--'),
(8311, 1974, 'TU1', 35, '--');

-- --------------------------------------------------------

--
-- Table structure for table `2014conferenceNew`
--

CREATE TABLE IF NOT EXISTS `2014conferenceNew` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `funccode` varchar(20) NOT NULL DEFAULT '',
  `date` date DEFAULT NULL,
  `funcdescr` varchar(200) DEFAULT NULL,
  `startTime` time NOT NULL,
  `endTime` time NOT NULL,
  `funccost` varchar(10) DEFAULT NULL,
  `cap` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=41 ;

--
-- Dumping data for table `2014conferenceNew`
--

INSERT INTO `2014conferenceNew` (`id`, `funccode`, `date`, `funcdescr`, `startTime`, `endTime`, `funccost`, `cap`) VALUES
(1, 'AMZWLK', '2013-04-08', 'The Amazing Walk Downhill into Banff for Dinner', '18:00:00', '00:00:00', '30.00', 40),
(2, 'SAWG01', '2013-04-09', 'Working Group 1: Issues for Managers - Learning from Incidents – Best Practices and Incorporation of Learnings', '10:30:00', '12:30:00', '--', 340),
(3, 'SAWG02', '2013-04-09', 'Working Group 2: Regulatory & Standards Developments - Challenges Meeting Regulations', '10:30:00', '12:30:00', '--', 137),
(4, 'SAWG06', '2013-04-09', 'Working Group 6: Human Factors - Tools & Techniques for Evaluating HF', '10:30:00', '12:30:00', '--', 100),
(5, 'SAWG08', '2013-04-09', 'Working Group 8: Inspection Tools & NDE - Digging for Accuracy', '10:30:00', '12:30:00', '--', 200),
(6, 'SAWG10', '2013-04-09', 'Working Group 10: Internal Corrosion - Crude Oil Perception vs Reality', '10:30:00', '12:30:00', '--', 130),
(7, 'SBWG02', '2013-04-09', 'Working Group 2: Regulatory & Standards Developments - Alberta Pipeline Safety Review', '13:30:00', '15:30:00', '--', 130),
(8, 'SBWG04', '2013-04-09', 'Working Group 4: Asset Management—Aging Infrastructure - Uncovering the Issues—Scientific Proof or Public Perception', '13:30:00', '15:30:00', '--', 200),
(9, 'SBWG07', '2013-04-09', 'Working Group 7: Pipeline Risk Management - Potential Risk Management Changes in CSA Standards', '13:30:00', '15:30:00', '--', 340),
(10, 'SBWG08', '2013-04-09', 'Working Group 8: Inspection Tools & NDE - Results & Discussion', '13:30:00', '15:30:00', '--', 100),
(11, 'SBWG10', '2013-04-09', 'Working Group 10: Internal Corrosion - Crude Corrosivity', '13:30:00', '15:30:00', '--', 130),
(12, 'SCWG01', '2013-04-09', 'Working Group 1: Issues for Managers - Lifecycle Pipeline Integrity Management – Implementation and Execution', '15:30:00', '17:30:00', '--', 340),
(13, 'SCWG03', '2013-04-09', 'Working Group 3: Upstream Pipelines:  Inspection, Corrosion, & Integrity Management - Technical & Regulatroy Updates Since 2011', '15:30:00', '17:30:00', '--', 200),
(14, 'SCWG06', '2013-04-09', 'Working Group 6: Human Factors - Implementing HF in an Organization', '15:30:00', '17:30:00', '--', 100),
(15, 'SCWG09', '2013-04-09', 'Working Group 9: External Corrosion & Coatings - Training & Certification of Workers', '15:30:00', '17:30:00', '--', 130),
(16, 'SCWG12', '2013-04-09', 'Working Group 12: Emergency Preparedness & Response - Public Perception & Implication of New Regulation', '15:30:00', '17:30:00', '--', 130),
(17, 'SDWG03', '2013-04-10', 'Working Group 3: Upstream Pipelines:  Inspection, Corrosion, & Integrity Management - Non-Metallics', '08:30:00', '10:30:00', '--', 340),
(18, 'SDWG04', '2013-04-10', 'Working Group 4: Assest Management—Aging Infrastructure - Urban Sprawl / Damage Prevention', '08:30:00', '10:30:00', '--', 100),
(19, 'SDWG05', '2013-04-10', 'Working Group 5: Environmental Assisted Cracking - EMAT & UT ILI—Status Report', '08:30:00', '10:30:00', '--', 200),
(20, 'SDWG09', '2013-04-10', 'Working Group 9: External Corrosion & Coatings - CP Designe & Facility Construction', '08:30:00', '10:30:00', '--', 130),
(21, 'SDWG11', '2013-04-10', 'Working Group 11: Managing Geotechnical Hazards - Geohazard Assessment for Proposed Projects', '08:30:00', '10:30:00', '--', 130),
(22, 'SEWG03', '2013-04-10', 'Working Group 3: Upstream Pipelines:  Inspection, Corrosion, & Integrity Management - Management of Pipeline Water Crossings', '10:30:00', '12:30:00', '--', 340),
(23, 'SEWG07', '2013-04-10', 'Working Group 7: Pipeline Risk Management - Better Consequence Representation', '10:30:00', '12:30:00', '--', 200),
(24, 'SFWG08', '2013-04-10', 'Working Group 8: Inspection Tools & NDE - Dealing with Outliers', '13:30:00', '15:30:00', '--', 130),
(25, 'SEWG11', '2013-04-10', 'Working Group 11: Managing Geotechnical Hazards - Geohazard Integrity Management ofr Operating Assets', '10:30:00', '12:30:00', '--', 130),
(26, 'SEWG12', '2013-04-10', 'Working Group 12: Emergency Preparedness & Response - Harmonization of Response', '10:30:00', '12:30:00', '--', 100),
(27, 'SFWG03', '2013-04-10', 'Working Group 3: Upstream Pipelines:  Inspection, Corrosion, & Integrity Management - Integrity Management—International & Canadian Perspective', '13:30:00', '15:30:00', '--', 340),
(28, 'SFWG05', '2013-04-10', 'Working Group 5: Environmental Assisted Cracking - SCC JIP2 Update', '13:30:00', '15:30:00', '--', 100),
(29, 'SFWG07', '2013-04-10', 'Working Group 7: Pipeline Risk Management - Incorporating Consequence into Integrity Management', '13:30:00', '15:30:00', '--', 200),
(30, 'SEWG09', '2013-04-10', 'Working Group 9: External Corrosion & Coatings - Coating Selection and Inspection', '10:30:00', '12:30:00', '--', 130),
(31, 'SFWG10', '2013-04-10', 'Working Group 10: Internal Corrosion - Condensate & Refined Products Issues', '13:30:00', '15:30:00', '--', 130),
(32, 'SGWG04', '2013-04-10', 'Working Group 4: Asset Management—Aging Infrastructure - Integrity Management—Work Smarter not Harder?', '15:30:00', '17:30:00', '--', 450),
(33, 'SGWG05', '2013-04-10', 'Working Group 5: Environmental Assisted Cracking - SCC Management—SCCDA', '15:30:00', '17:30:00', '--', 340),
(34, 'SGWG12', '2013-04-10', 'Working Group 12: Emergency Preparedness & Response - Integrity & Emergency Management', '15:30:00', '17:30:00', '--', 200),
(35, 'TU1', '2013-04-08', 'Tutorial 1: Fundamental for Junior Professional', '09:00:00', '16:30:00', '--', 130),
(36, 'TU2', '2013-04-08', 'Tutorial 2: Pipeline Integrity Management', '09:00:00', '12:00:00', '--', 340),
(37, 'TU3', '2013-04-08', 'Tutorial 3: Integrity First Program', '09:00:00', '12:00:00', '--', 100),
(38, 'TU4', '2013-04-08', 'Tutorial 4: Human Factors 101', '13:30:00', '16:30:00', '--', 130),
(39, 'TU5', '2013-04-08', 'Tutorial 5: Unpiggable Pipelines & Tethered Tool Solutions: Do''s and Don''ts', '13:30:00', '16:30:00', '--', 340),
(40, 'TU6', '2013-04-08', 'Tutorial 6: GIS Spatial Database Management Systems for Pipelines', '13:30:00', '16:30:00', '--', 200);

-- --------------------------------------------------------

--
-- Table structure for table `2014holdDetail`
--

CREATE TABLE IF NOT EXISTS `2014holdDetail` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `vid` int(10) DEFAULT NULL,
  `funccode` varchar(10) DEFAULT NULL,
  `funcid` int(3) NOT NULL,
  `charged` varchar(10) DEFAULT NULL,
  `date_changed` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8311 ;

--
-- Dumping data for table `2014holdDetail`
--

INSERT INTO `2014holdDetail` (`id`, `vid`, `funccode`, `funcid`, `charged`, `date_changed`) VALUES
(8310, 1974, 'TU1', 35, '--', '2014-06-13');

-- --------------------------------------------------------

--
-- Table structure for table `2014ipTrack`
--

CREATE TABLE IF NOT EXISTS `2014ipTrack` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(50) NOT NULL DEFAULT '',
  `invoice_num` varchar(50) NOT NULL DEFAULT '',
  `email_address` varchar(100) NOT NULL DEFAULT '',
  `date_attempted` varchar(50) NOT NULL DEFAULT '',
  `full_date` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `2014paymentHistory`
--

CREATE TABLE IF NOT EXISTS `2014paymentHistory` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `vid` int(10) NOT NULL DEFAULT '0',
  `pay_amount` decimal(7,2) DEFAULT NULL,
  `date_paid` varchar(12) NOT NULL DEFAULT '',
  `time_paid` varchar(10) NOT NULL DEFAULT '',
  `transaction_type` varchar(20) NOT NULL DEFAULT '',
  `response` varchar(50) NOT NULL DEFAULT '',
  `response_id` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=957 ;

--
-- Dumping data for table `2014paymentHistory`
--

INSERT INTO `2014paymentHistory` (`id`, `vid`, `pay_amount`, `date_paid`, `time_paid`, `transaction_type`, `response`, `response_id`) VALUES
(955, 1973, 78.75, '2014-06-13', '09:34', 'CC', 'APPROVED', '10002446'),
(956, 1974, 78.75, '2014-06-13', '12:33', 'CC', 'APPROVED', '10002449');

-- --------------------------------------------------------

--
-- Table structure for table `2014paymentSponsorship`
--

CREATE TABLE IF NOT EXISTS `2014paymentSponsorship` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `vid` int(10) NOT NULL DEFAULT '0',
  `pay_amount` decimal(7,2) DEFAULT NULL,
  `date_paid` varchar(12) NOT NULL DEFAULT '',
  `time_paid` varchar(10) NOT NULL DEFAULT '',
  `transaction_type` varchar(20) NOT NULL DEFAULT '',
  `response` varchar(50) NOT NULL DEFAULT '',
  `response_id` varchar(30) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=955 ;

-- --------------------------------------------------------

--
-- Table structure for table `2014promo`
--

CREATE TABLE IF NOT EXISTS `2014promo` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `promoCode` varchar(12) DEFAULT NULL,
  `company` varchar(200) NOT NULL,
  `invoice` varchar(10) NOT NULL,
  `dateCreated` date NOT NULL,
  `timeCreated` time NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=188 ;

--
-- Dumping data for table `2014promo`
--

INSERT INTO `2014promo` (`id`, `promoCode`, `company`, `invoice`, `dateCreated`, `timeCreated`, `enabled`) VALUES
(186, 'BN.Y7KY.0186', 'test', '', '2014-06-12', '11:43:38', 1),
(187, 'BN.53FZ.0187', 'i.d. associates', '', '2014-06-13', '12:35:31', 1);

-- --------------------------------------------------------

--
-- Table structure for table `2014sponsor`
--

CREATE TABLE IF NOT EXISTS `2014sponsor` (
  `sid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sal` varchar(4) NOT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `company` varchar(140) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `sponcode` varchar(6) NOT NULL,
  `invoicedate` varchar(50) DEFAULT NULL,
  `totalcharged` decimal(7,2) NOT NULL,
  `totalpaid` decimal(7,2) DEFAULT '0.00',
  `datepaid` varchar(12) NOT NULL DEFAULT '',
  `totaldue` decimal(7,2) DEFAULT NULL,
  `paytype` varchar(50) DEFAULT NULL,
  `miraresponse` varchar(50) DEFAULT NULL,
  `miraamt` decimal(7,2) DEFAULT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 PACK_KEYS=0 AUTO_INCREMENT=1972 ;

-- --------------------------------------------------------

--
-- Table structure for table `2014visitor`
--

CREATE TABLE IF NOT EXISTS `2014visitor` (
  `vid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `confcode` varchar(4) DEFAULT '4IL',
  `sal` varchar(4) NOT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `nickname` varchar(50) DEFAULT NULL,
  `phone` varchar(100) DEFAULT NULL,
  `fax` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `user_password` varchar(50) DEFAULT NULL,
  `company` varchar(140) DEFAULT NULL,
  `businesstype` varchar(50) NOT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `billing` varchar(5) NOT NULL DEFAULT '',
  `billing_sal` varchar(4) DEFAULT NULL,
  `billing_fname` varchar(50) DEFAULT NULL,
  `billing_lname` varchar(100) DEFAULT NULL,
  `billing_company` varchar(140) DEFAULT NULL,
  `billing_title` varchar(100) DEFAULT NULL,
  `billing_address1` varchar(100) DEFAULT NULL,
  `billing_address2` varchar(100) DEFAULT NULL,
  `billing_city` varchar(100) DEFAULT NULL,
  `billing_state` varchar(100) DEFAULT NULL,
  `billing_country` varchar(100) DEFAULT NULL,
  `billing_zip` varchar(50) DEFAULT NULL,
  `billing_phone` varchar(100) DEFAULT NULL,
  `billing_fax` varchar(100) DEFAULT NULL,
  `billing_email` varchar(150) DEFAULT NULL,
  `funccode` varchar(20) DEFAULT NULL,
  `totalcharged` decimal(7,2) DEFAULT NULL,
  `invoicedate` varchar(50) DEFAULT NULL,
  `totalpaid` decimal(7,2) DEFAULT '0.00',
  `datepaid` varchar(12) NOT NULL DEFAULT '',
  `totaldue` decimal(7,2) DEFAULT NULL,
  `paytype` varchar(50) DEFAULT NULL,
  `miraresponse` varchar(50) DEFAULT NULL,
  `miraamt` decimal(7,2) DEFAULT NULL,
  `reg_status` varchar(20) NOT NULL DEFAULT '',
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 PACK_KEYS=0 AUTO_INCREMENT=1975 ;

--
-- Dumping data for table `2014visitor`
--

INSERT INTO `2014visitor` (`vid`, `confcode`, `sal`, `fname`, `lname`, `title`, `nickname`, `phone`, `fax`, `email`, `user_password`, `company`, `businesstype`, `address1`, `address2`, `city`, `state`, `country`, `zip`, `billing`, `billing_sal`, `billing_fname`, `billing_lname`, `billing_company`, `billing_title`, `billing_address1`, `billing_address2`, `billing_city`, `billing_state`, `billing_country`, `billing_zip`, `billing_phone`, `billing_fax`, `billing_email`, `funccode`, `totalcharged`, `invoicedate`, `totalpaid`, `datepaid`, `totaldue`, `paytype`, `miraresponse`, `miraamt`, `reg_status`) VALUES
(1973, '4IL', '', 'Mike', 'Powney', 'Senior Designer', 'Mike', '7802664202', '', 'mike@idassociates.ab.ca', '', 'I.D. Associates', 'Consultant', '11013 Jasper Ave', '', 'Edmonton', 'AB', 'DZ', 'T5K 0K6', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'MON', 75.00, '2014-06-13', 78.75, '2014-06-13', 0.00, 'VI', 'APPROVED', 78.75, ''),
(1974, '4IL', '', 'Mike', 'Powney', 'Senior Designer', 'Mike', '7802664202', '', 'mike@idassociates.ab.ca', '', 'I.D. Associates', 'Consultant', '11013 Jasper Ave', '', 'Edmonton', 'AB', 'AS', 'T5K 0K6', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'MON', 75.00, '2014-06-13', 78.75, '2014-06-13', 0.00, 'VI', 'APPROVED', 78.75, '');

-- --------------------------------------------------------

--
-- Table structure for table `2014visitorProfile`
--

CREATE TABLE IF NOT EXISTS `2014visitorProfile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(70) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(4) NOT NULL,
  `invoicenum` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `2014workGroups`
--

CREATE TABLE IF NOT EXISTS `2014workGroups` (
  `workgroup` int(3) NOT NULL,
  `title` varchar(150) NOT NULL,
  PRIMARY KEY (`workgroup`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `2014workGroups`
--

INSERT INTO `2014workGroups` (`workgroup`, `title`) VALUES
(1, 'Issues for Managers'),
(2, 'Regulatory & Standards Developmnets'),
(3, 'Upstream Pipelines: Inspection, Corrosion, & Integrity Management'),
(4, 'Asset Management - Aging Infrastructure'),
(5, 'Environmental Assisted Cracking'),
(6, 'Human Factors'),
(7, 'Pipeline Risk Management'),
(8, 'Inspection Tools & NDE'),
(9, 'External Corrosion & Coatings'),
(10, 'Internal Corrosion'),
(11, 'Managing Geotechnical Hazards'),
(12, 'Emergency Preparedness & Response');

-- --------------------------------------------------------

--
-- Table structure for table `asmeCountryList`
--

CREATE TABLE IF NOT EXISTS `asmeCountryList` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `CountryCode` varchar(3) NOT NULL,
  `iso2` varchar(2) NOT NULL,
  `CountryName` varchar(100) NOT NULL,
  `Continent` varchar(100) NOT NULL,
  `EUCountry` varchar(100) NOT NULL,
  `PhoneCountryCode` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=262 ;

--
-- Dumping data for table `asmeCountryList`
--

INSERT INTO `asmeCountryList` (`id`, `CountryCode`, `iso2`, `CountryName`, `Continent`, `EUCountry`, `PhoneCountryCode`) VALUES
(1, 'ABW', 'AW', 'Aruba', 'North America', 'N', '297'),
(2, 'AFG', 'AF', 'Afghanistan', 'Asia', 'N', '93'),
(3, 'AGO', 'AO', 'Angola', 'Africa', 'N', '244'),
(4, 'AIA', 'AI', 'Anguilla', 'North America', 'N', '264'),
(5, 'ALB', 'AL', 'Albania', 'Europe', 'N', '355'),
(6, 'AND', 'AD', 'Andorra', 'Europe', 'N', '376'),
(7, 'ANT', 'AN', 'Netherlands Antilles', 'North America', 'N', '599'),
(8, 'ARE', 'AE', 'United Arab Emirates', 'Asia', 'N', '971'),
(9, 'ARG', 'AR', 'Argentina', 'South America', 'N', '54'),
(10, 'ARM', 'AM', 'Armenia', 'Asia', 'N', '374'),
(11, 'ATA', 'AQ', 'Antarctica', 'Antarctica', 'N', '672'),
(12, 'ATF', 'TF', 'French Southern Terr', 'Antarctica', 'N', '33'),
(13, 'ATG', 'AG', 'Antigua And Barbuda', 'North America', 'N', '268'),
(14, 'AUS', 'AU', 'Australia', 'Oceania', 'N', '61'),
(15, 'AUT', 'AT', 'Austria', 'Europe', 'Y', '43'),
(16, 'AZE', 'AZ', 'Azerbaijan', 'Asia', 'N', '994'),
(17, 'BDI', 'BI', 'Burundi', 'Africa', 'N', '257'),
(18, 'BEL', 'BE', 'Belgium', 'Europe', 'Y', '32'),
(19, 'BEN', 'BJ', 'Benin', 'Africa', 'N', '229'),
(20, 'BFA', 'BF', 'Burkin Faso', 'Africa', 'N', '226'),
(21, 'BGD', 'BD', 'Bangladesh', 'Asia', 'N', '880'),
(22, 'BGR', 'BG', 'Bulgaria', 'Europe', 'Y', '359'),
(23, 'BHR', 'BH', 'Bahrain', 'Asia', 'N', '973'),
(24, 'BHS', 'BS', 'Bahamas', 'North America', 'N', '242'),
(25, 'BIH', 'BA', 'Bosnia And Herzegowina', 'Europe', 'N', '387'),
(26, 'BLR', 'BY', 'Belarus', 'Europe', 'N', '375'),
(27, 'BLZ', 'BZ', 'Belize', 'North America', 'N', '501'),
(28, 'BMU', 'BM', 'Bermuda', 'North America', 'N', '441'),
(29, 'BOL', 'BO', 'Bolivia', 'South America', 'N', '591'),
(30, 'BOR', '', 'Borneo - East Indies', 'Asia', 'N', ''),
(31, 'BOU', '', 'Bougainville', 'Oceania', 'N', ''),
(32, 'BRA', 'BR', 'Brazil', 'South America', 'N', '55'),
(33, 'BRB', 'BB', 'Barbados', 'North America', 'N', '246'),
(34, 'BRN', 'BN', 'Brunei Darussalam', 'Asia', 'N', '673'),
(35, 'BTN', 'BT', 'Bhutan', 'Asia', 'N', '975'),
(36, 'BUR', '', 'Burma', 'Asia', 'N', '95'),
(37, 'BVT', 'BV', 'Bouvet Island', 'Antarctica', 'N', '47'),
(38, 'BWA', 'BW', 'Botswana', 'Africa', 'N', '267'),
(39, 'BWI', '', 'West Indies', 'North America', 'N', ''),
(40, 'BYE', '', 'Byelorussia', 'Europe', 'N', ''),
(41, 'CAA', '', 'Canary Islands', 'North America', 'N', ''),
(42, 'CAF', 'CF', 'Central African Republic', 'Africa', 'N', '236'),
(43, 'CAN', 'CA', 'Canada', 'North America', 'N', '1'),
(44, 'CCK', 'CC', 'Cocos (Keeling) Islands', 'Asia', 'N', '61'),
(45, 'CHE', 'CH', 'Switzerland', 'Europe', 'Y', '41'),
(46, 'CHL', 'CL', 'Chile', 'South America', 'N', '56'),
(47, 'CHN', 'CN', 'People''s Republic of China', 'Asia', 'N', '86'),
(48, 'CIS', '', 'Channel Islands', 'Europe', 'N', ''),
(49, 'CIV', 'CI', 'Cote DIvoire', 'Africa', 'N', '225'),
(50, 'CMR', 'CM', 'Cameroon', 'Africa', 'N', '237'),
(51, 'COD', 'CD', 'Congo-Democratic Republic', 'Africa', 'N', '243'),
(52, 'COG', 'CG', 'Congo', 'Africa', 'N', '242'),
(53, 'COK', 'CK', 'Cook Islands', 'Oceania', 'N', '682'),
(54, 'COL', 'CO', 'Colombia', 'South America', 'N', '57'),
(55, 'COM', 'KM', 'Comoros', 'Africa', 'N', '269'),
(56, 'CPV', 'CV', 'Cape Verde', 'Africa', 'N', '238'),
(57, 'CRI', 'CR', 'Costa Rica', 'North America', 'N', '506'),
(58, 'CUB', 'CU', 'Cuba', 'North America', 'N', '53'),
(59, 'CUR', '', 'Curaco', 'North America', 'N', ''),
(60, 'CXR', 'CX', 'Christmas Island', 'Asia', 'N', '61'),
(61, 'CYM', 'KY', 'Cayman Islands', 'North America', 'N', '345'),
(62, 'CYP', 'CY', 'Cyprus', 'Asia', 'Y', '357'),
(63, 'CZE', 'CZ', 'Czech Republic', 'Europe', 'Y', '420'),
(64, 'DEU', 'DE', 'Germany', 'Europe', 'Y', '49'),
(65, 'DJI', 'DJ', 'Djibouti', 'Africa', 'N', '253'),
(66, 'DMA', 'DM', 'Dominica', 'North America', 'N', '767'),
(67, 'DNK', 'DK', 'Denmark', 'Europe', 'Y', '45'),
(68, 'DOM', 'DO', 'Dominican Republic', 'North America', 'N', '809'),
(69, 'DZA', 'DZ', 'Algeria', 'Africa', 'N', '213'),
(70, 'ECU', 'EC', 'Ecuador', 'South America', 'N', '593'),
(71, 'EGY', 'EG', 'Egypt', 'Africa', 'N', '20'),
(72, 'ERI', 'ER', 'Eritrea', 'Africa', 'N', '291'),
(73, 'ESH', 'EH', 'Western Sahara', 'Africa', 'N', '212'),
(74, 'ESP', 'ES', 'Spain', 'Europe', 'Y', '34'),
(75, 'EST', 'EE', 'Estonia', 'Europe', 'Y', '372'),
(76, 'ETH', 'ET', 'Ethiopia', 'Africa', 'N', '251'),
(77, 'FIN', 'FI', 'Finland', 'Europe', 'Y', '358'),
(78, 'FJI', 'FJ', 'Fiji', 'Oceania', 'N', '679'),
(79, 'FLK', 'FK', 'Falkland Islands', 'South America', 'N', '500'),
(80, 'FRA', 'FR', 'France', 'Europe', 'Y', '33'),
(81, 'FRO', 'FO', 'Faroe Islands', 'Europe', 'N', '298'),
(82, 'FSM', 'FM', 'Micronesia-Federated Stat', 'Oceania', 'N', '691'),
(83, 'GAB', 'GA', 'Gabon', 'Africa', 'N', '241'),
(84, 'GBR', 'GB', 'United Kingdom', 'Europe', 'Y', '44'),
(85, 'GEO', 'GE', 'Georgia', 'Asia', 'N', '995'),
(86, 'GHA', 'GH', 'Ghana', 'Africa', 'N', '233'),
(87, 'GIB', 'GI', 'Gibraltar', 'Europe', 'N', '350'),
(88, 'GIN', 'GN', 'Guinea', 'Africa', 'N', '224'),
(89, 'GLP', 'GP', 'Guadeloupe', 'North America', 'N', '590'),
(90, 'GMB', 'GM', 'Gambia', 'Africa', 'N', '220'),
(91, 'GNB', 'GW', 'Guinea-Bissau', 'Africa', 'N', '245'),
(92, 'GNQ', 'GQ', 'Equatorial Guinea', 'Africa', 'N', '240'),
(93, 'GRC', 'GR', 'Greece', 'Europe', 'Y', '30'),
(94, 'GRD', 'GD', 'Grenada', 'North America', 'N', '473'),
(95, 'GRL', 'GL', 'Greenland', 'North America', 'N', '299'),
(96, 'GTM', 'GT', 'Guatemala', 'North America', 'N', '502'),
(97, 'GUF', 'GF', 'French Guiana', 'South America', 'N', '594'),
(98, 'GUY', 'GY', 'Guyana', 'South America', 'N', '592'),
(99, 'HKG', 'HK', 'Hong Kong', 'Asia', 'N', '852'),
(100, 'HMD', 'HM', 'Heard & Mcdonald Islands', 'Antarctica', 'N', '672'),
(101, 'HND', 'HN', 'Honduras', 'North America', 'N', '504'),
(102, 'HOL', '', 'Holland Netherlands', 'Europe', 'N', ''),
(103, 'HRV', 'HR', 'Croatia (Hrvatska)', 'Europe', 'N', '385'),
(104, 'HTI', 'HT', 'Haiti', 'North America', 'N', '509'),
(105, 'HUN', 'HU', 'Hungary', 'Europe', 'Y', '36'),
(106, 'IDN', 'ID', 'Indonesia', 'Asia', 'N', '62'),
(107, 'IND', 'IN', 'India', 'Asia', 'N', '91'),
(108, 'IOM', '', 'Isle of Man', 'Europe', 'N', '44'),
(109, 'IOT', 'IO', 'British Indian Ocean Terr', 'Asia', 'N', '246'),
(110, 'IRL', 'IE', 'Ireland', 'Europe', 'Y', '353'),
(111, 'IRN', 'IR', 'Iran(Islamic Republic Of)', 'Asia', 'N', '98'),
(112, 'IRQ', 'IQ', 'Iraq', 'Asia', 'N', '964'),
(113, 'ISL', 'IS', 'Iceland', 'Europe', 'N', '354'),
(114, 'ISR', 'IL', 'Israel', 'Asia', 'N', '972'),
(115, 'ITA', 'IT', 'Italy', 'Europe', 'Y', '39'),
(116, 'IVO', '', 'Ivory Coast', 'Africa', 'N', ''),
(117, 'JAM', 'JM', 'Jamaica', 'North America', 'N', '876'),
(118, 'JOR', 'JO', 'Jordan', 'Asia', 'N', '962'),
(119, 'JPN', 'JP', 'Japan', 'Asia', 'N', '81'),
(120, 'KAM', '', 'Kampuchea', 'Asia', 'N', ''),
(121, 'KAZ', 'KZ', 'Kazakhstan', 'Asia', 'N', '7'),
(122, 'KEN', 'KE', 'Kenya', 'Africa', 'N', '254'),
(123, 'KGZ', 'KG', 'Kyrgyzstan', 'Asia', 'N', '996'),
(124, 'KHM', 'KH', 'Cambodia', 'Asia', 'N', '855'),
(125, 'KIR', 'KI', 'Kiribati', 'Oceania', 'N', '686'),
(126, 'KNA', 'KN', 'Saint Kitts And Nevis', 'North America', 'N', '869'),
(127, 'KOR', 'KR', 'Republic of Korea', 'Asia', 'N', '82'),
(128, 'KWT', 'KW', 'Kuwait', 'Asia', 'N', '965'),
(129, 'LAO', 'LA', 'Lao People Demo Republic', 'Asia', 'N', '856'),
(130, 'LBN', 'LB', 'Lebanon', 'Asia', 'N', '961'),
(131, 'LBR', 'LR', 'Liberia', 'Africa', 'N', '231'),
(132, 'LBY', 'LY', 'Libyan Arab Jamahiriya', 'Africa', 'N', '218'),
(133, 'LCA', 'LC', 'Saint Lucia', 'North America', 'N', '758'),
(134, 'LIE', 'LI', 'Liechtenstein', 'Europe', 'N', '423'),
(135, 'LKA', 'LK', 'Sri Lanka', 'Asia', 'N', '94'),
(136, 'LSO', 'LS', 'Lesotho', 'Africa', 'N', '266'),
(137, 'LTU', 'LT', 'Lithuania', 'Europe', 'Y', '370'),
(138, 'LUX', 'LU', 'Luxembourg', 'Europe', 'Y', '352'),
(139, 'LVA', 'LV', 'Latvia', 'Europe', 'Y', '371'),
(140, 'MAC', 'MO', 'Macau', 'Asia', 'N', '853'),
(141, 'MAR', 'MA', 'Morocco', 'Africa', 'N', '212'),
(142, 'MCO', 'MC', 'Monaco', 'Europe', 'N', '377'),
(143, 'MDA', 'MD', 'Moldova - Republic Of', 'Europe', 'N', '373'),
(144, 'MDG', 'MG', 'Madagascar', 'Africa', 'N', '261'),
(145, 'MDV', 'MV', 'Maldives', 'Asia', 'N', '960'),
(146, 'MEX', 'MX', 'Mexico', 'North America', 'N', '52'),
(147, 'MHL', 'MH', 'Marshall Islands', 'Oceania', 'N', '692'),
(148, 'MKD', 'MK', 'Macedonia (Yugoslav Rep)', 'Europe', 'N', '389'),
(149, 'MLI', 'ML', 'Mali', 'Africa', 'N', '223'),
(150, 'MLT', 'MT', 'Malta', 'Europe', 'N', '356'),
(151, 'MMR', 'MM', 'Myanmar', 'Asia', 'N', '95'),
(152, 'MNG', 'MN', 'Mongolia', 'Asia', 'N', '976'),
(153, 'MNP', 'MP', 'Northern Mariana Islands', 'Oceania', 'N', '1670'),
(154, 'MNT', '', 'Montenegro', 'Europe', 'N', ''),
(155, 'MOZ', 'MZ', 'Mozambique', 'Africa', 'N', '258'),
(156, 'MRT', 'MR', 'Mauritania', 'Africa', 'N', '222'),
(157, 'MSR', 'MS', 'Montserrat', 'North America', 'N', '664'),
(158, 'MTQ', 'MQ', 'Martinique', 'North America', 'N', '596'),
(159, 'MUS', 'MU', 'Mauritius', 'Africa', 'N', '230'),
(160, 'MWI', 'MW', 'Malawi', 'Africa', 'N', '265'),
(161, 'MYS', 'MY', 'Malaysia', 'Asia', 'N', '60'),
(162, 'MYT', 'YT', 'Mayotte', 'Africa', 'N', '269'),
(163, 'NAM', 'NA', 'Namibia', 'Africa', 'N', '264'),
(164, 'NCL', 'NC', 'New Caledonia', 'Oceania', 'N', '687'),
(165, 'NER', 'NE', 'Niger', 'Africa', 'N', '227'),
(166, 'NFK', 'NF', 'Norfolk Island', 'Oceania', 'N', '672'),
(167, 'NGA', 'NG', 'Nigeria', 'Africa', 'N', '234'),
(168, 'NGU', '', 'New Guinea', 'Oceania', 'N', '675'),
(169, 'NIC', 'NI', 'Nicaragua', 'North America', 'N', '505'),
(170, 'NIU', 'NU', 'Niue', 'Oceania', 'N', '683'),
(171, 'NLD', 'NL', 'Netherlands', 'Europe', 'Y', '31'),
(172, 'NOR', 'NO', 'Norway', 'Europe', 'Y', '47'),
(173, 'NOT', '', 'Northern Ireland', 'Europe', 'N', ''),
(174, 'NPL', 'NP', 'Nepal', 'Asia', 'N', '977'),
(175, 'NRU', 'NR', 'Nauru', 'Oceania', 'N', '674'),
(176, 'NZL', 'NZ', 'New Zealand', 'Oceania', 'N', '64'),
(177, 'OKI', '', 'Okinawa Japan', 'Asia', 'N', ''),
(178, 'OMN', 'OM', 'Oman', 'Asia', 'N', '968'),
(179, 'PAK', 'PK', 'Pakistan', 'Asia', 'N', '92'),
(180, 'PAN', 'PA', 'Panama', 'North America', 'N', '507'),
(181, 'PCN', 'PN', 'Pitcairn', 'Oceania', 'N', '672'),
(182, 'PER', 'PE', 'Peru', 'South America', 'N', '51'),
(183, 'PHL', 'PH', 'Philippines', 'Asia', 'N', '63'),
(184, 'PLW', 'PW', 'Palau', 'Oceania', 'N', '680'),
(185, 'PNG', 'PG', 'Papua New Guinea', 'Oceania', 'N', '675'),
(186, 'POL', 'PL', 'Poland', 'Europe', 'N', '48'),
(187, 'PRI', 'PR', 'Puerto Rico', 'North America', 'N', '1'),
(188, 'PRK', 'KP', 'Democratic People''s Republic of Korea', 'Asia', 'N', '850'),
(189, 'PRT', 'PT', 'Portugal', 'Europe', 'Y', '351'),
(190, 'PRY', 'PY', 'Paraguay', 'South America', 'N', '595'),
(191, 'PSE', 'PS', 'Palestinian Territory, Occupied', 'Asia', 'N', '970'),
(192, 'PYF', 'PF', 'French Polynesia', 'Oceania', 'N', '689'),
(193, 'QAT', 'QA', 'Qatar', 'Asia', 'N', '974'),
(194, 'REU', 'RE', 'Reunion', 'Africa', 'N', '262'),
(195, 'ROU', 'RO', 'Romania', 'Europe', 'Y', '40'),
(196, 'RUS', 'RU', 'Russian Federation', 'Europe', 'N', '7'),
(197, 'RWA', 'RW', 'Rwanda', 'Africa', 'N', '250'),
(198, 'SAU', 'SA', 'Saudi Arabia', 'Asia', 'N', '966'),
(199, 'SCO', '', 'Scotland', 'Europe', 'Y', '44'),
(200, 'SDN', 'SD', 'Sudan', 'Africa', 'N', '249'),
(201, 'SEN', 'SN', 'Senegal', 'Africa', 'N', '221'),
(202, 'SER', '', 'Serbia', 'Europe', 'N', ''),
(203, 'SGP', 'SG', 'Singapore', 'Asia', 'N', '65'),
(204, 'SGS', 'GS', 'South Georgia', 'Antarctica', 'N', '999'),
(205, 'SHN', 'SH', 'St. Helena', 'Africa', 'N', '290'),
(206, 'SJM', 'SJ', 'Svalbard & Jan Mayen Isl', 'Europe', 'N', '47'),
(207, 'SLB', 'SB', 'Solomon Islands', 'Oceania', 'N', '677'),
(208, 'SLE', 'SL', 'Sierra Leone', 'Africa', 'N', '232'),
(209, 'SLV', 'SV', 'El Salvador', 'North America', 'N', '503'),
(210, 'SMR', 'SM', 'San Marino', 'Europe', 'N', '378'),
(211, 'SOM', 'SO', 'Somalia', 'Africa', 'N', '252'),
(212, 'SPM', 'PM', 'St. Pierre And Miquelon', 'North America', 'N', '508'),
(213, 'SRB', '', 'Serbia', '', 'N', '381'),
(214, 'STP', 'ST', 'Sao Tome And Principe', 'Africa', 'N', '239'),
(215, 'SUR', 'SR', 'Suriname', 'South America', 'N', '597'),
(216, 'SVK', 'SK', 'Slovakia(Slovak Republic)', 'Europe', 'Y', '421'),
(217, 'SVN', 'SI', 'Slovenia', 'Europe', 'Y', '386'),
(218, 'SWE', 'SE', 'Sweden', 'Europe', 'Y', '46'),
(219, 'SWZ', 'SZ', 'Swaziland', 'Africa', 'N', '268'),
(220, 'SYC', 'SC', 'Seychelles', 'Africa', 'N', '248'),
(221, 'SYR', 'SY', 'Syrian Arab Republic', 'Asia', 'N', '963'),
(222, 'TAH', '', 'Tahiti', 'Oceania', 'N', ''),
(223, 'TCA', 'TC', 'Turks And Caicos Islands', 'North America', 'N', '649'),
(224, 'TCD', 'TD', 'Chad', 'Africa', 'N', '235'),
(225, 'TGO', 'TG', 'Togo', 'Africa', 'N', '228'),
(226, 'THA', 'TH', 'Thailand', 'Asia', 'N', '66'),
(227, 'TJK', 'TJ', 'Tajikistan', 'Asia', 'N', '992'),
(228, 'TKL', 'TK', 'Tokelau', 'Oceania', 'N', '690'),
(229, 'TKM', 'TM', 'Turkmenistan', 'Asia', 'N', '993'),
(230, 'TLS', 'TL', 'East Timor', 'Asia', 'N', '670'),
(231, 'TON', 'TO', 'Tonga', 'Oceania', 'N', '676'),
(232, 'TTO', 'TT', 'Trinidad And Tobago', 'North America', 'N', '868'),
(233, 'TUN', 'TN', 'Tunisia', 'Africa', 'N', '216'),
(234, 'TUR', 'TR', 'Turkey', 'Asia', 'N', '90'),
(235, 'TUV', 'TV', 'Tuvalu', 'Oceania', 'N', '688'),
(236, 'TWN', 'TW', 'Taiwan', 'Asia', 'N', '886'),
(237, 'TZA', 'TZ', 'Tanzania-United Republic', 'Africa', 'N', '255'),
(238, 'UGA', 'UG', 'Uganda', 'Africa', 'N', '256'),
(239, 'UKR', 'UA', 'Ukraine', 'Europe', 'N', '380'),
(240, 'UMI', 'UM', 'U S Minor Island', 'Oceania', 'N', '1'),
(241, 'UPP', '', 'Upper Volta Africa', 'Africa', 'N', ''),
(242, 'URC', '', 'United Republic Cameroon', 'Africa', 'N', ''),
(243, 'URY', 'UY', 'Uruguay', 'South America', 'N', '598'),
(244, 'USA', 'US', 'United States', 'North America', 'N', '1'),
(245, 'UZB', 'UZ', 'Uzbekistan', 'Asia', 'N', '998'),
(246, 'VAT', 'VA', 'Holy See (Vatican City )', 'Europe', 'N', '39'),
(247, 'VCT', 'VC', 'St Vincent And Grenadines', 'North America', 'N', '784'),
(248, 'VEN', 'VE', 'Venezuela', 'South America', 'N', '58'),
(249, 'VGB', 'VG', 'Virgin Islands (British)', 'North America', 'N', '1'),
(250, 'VNM', 'VN', 'Viet Nam', 'Asia', 'N', '84'),
(251, 'VUT', 'VU', 'Vanuatu', 'Oceania', 'N', '678'),
(252, 'WAF', '', 'West Africa', 'Africa', 'N', ''),
(253, 'WAL', '', 'Wales', 'Europe', 'Y', '44'),
(254, 'WLF', 'WF', 'Wallis And Futuna Islands', 'Oceania', 'N', '681'),
(255, 'WSM', 'WS', 'Samoa', 'Oceania', 'N', '685'),
(256, 'YEM', 'YE', 'Yemen', 'Asia', 'N', '967'),
(257, 'YUG', '', 'Yugoslavia', 'Europe', 'N', '381'),
(258, 'ZAF', 'ZA', 'South Africa', 'Africa', 'N', '27'),
(259, 'ZAI', '', 'Zaire', 'Africa', 'N', ''),
(260, 'ZMB', 'ZM', 'Zambia', 'Africa', 'N', '260'),
(261, 'ZWE', 'ZW', 'Zimbabwe', 'Africa', 'N', '263');

-- --------------------------------------------------------

--
-- Table structure for table `countryList`
--

CREATE TABLE IF NOT EXISTS `countryList` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `countryName` varchar(200) NOT NULL,
  `iso2` varchar(2) NOT NULL,
  `iso3` varchar(3) NOT NULL,
  `countryCode` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=241 ;

--
-- Dumping data for table `countryList`
--

INSERT INTO `countryList` (`id`, `countryName`, `iso2`, `iso3`, `countryCode`) VALUES
(1, 'AALAND ISLANDS', 'AX', 'ALA', 248),
(2, 'AFGHANISTAN', 'AF', 'AFG', 4),
(3, 'ALBANIA', 'AL', 'ALB', 8),
(4, 'ALGERIA', 'DZ', 'DZA', 12),
(5, 'AMERICAN SAMOA', 'AS', 'ASM', 16),
(6, 'ANDORRA', 'AD', 'AND', 20),
(7, 'ANGOLA', 'AO', 'AGO', 24),
(8, 'ANGUILLA', 'AI', 'AIA', 660),
(9, 'ANTARCTICA', 'AQ', 'ATA', 10),
(10, 'ANTIGUA AND BARBUDA', 'AG', 'ATG', 28),
(11, 'ARGENTINA', 'AR', 'ARG', 32),
(12, 'ARMENIA', 'AM', 'ARM', 51),
(13, 'ARUBA', 'AW', 'ABW', 533),
(14, 'AUSTRALIA', 'AU', 'AUS', 36),
(15, 'AUSTRIA', 'AT', 'AUT', 40),
(16, 'AZERBAIJAN', 'AZ', 'AZE', 31),
(17, 'BAHAMAS', 'BS', 'BHS', 44),
(18, 'BAHRAIN', 'BH', 'BHR', 48),
(19, 'BANGLADESH', 'BD', 'BGD', 50),
(20, 'BARBADOS', 'BB', 'BRB', 52),
(21, 'BELARUS', 'BY', 'BLR', 112),
(22, 'BELGIUM', 'BE', 'BEL', 56),
(23, 'BELIZE', 'BZ', 'BLZ', 84),
(24, 'BENIN', 'BJ', 'BEN', 204),
(25, 'BERMUDA', 'BM', 'BMU', 60),
(26, 'BHUTAN', 'BT', 'BTN', 64),
(27, 'BOLIVIA', 'BO', 'BOL', 68),
(28, 'BOSNIA AND HERZEGOWINA', 'BA', 'BIH', 70),
(29, 'BOTSWANA', 'BW', 'BWA', 72),
(30, 'BOUVET ISLAND', 'BV', 'BVT', 74),
(31, 'BRAZIL', 'BR', 'BRA', 76),
(32, 'BRITISH INDIAN OCEAN TERRITORY', 'IO', 'IOT', 86),
(33, 'BRUNEI DARUSSALAM', 'BN', 'BRN', 96),
(34, 'BULGARIA', 'BG', 'BGR', 100),
(35, 'BURKINA FASO', 'BF', 'BFA', 854),
(36, 'BURUNDI', 'BI', 'BDI', 108),
(37, 'CAMBODIA', 'KH', 'KHM', 116),
(38, 'CAMEROON', 'CM', 'CMR', 120),
(39, 'CANADA', 'CA', 'CAN', 124),
(40, 'CAPE VERDE', 'CV', 'CPV', 132),
(41, 'CAYMAN ISLANDS', 'KY', 'CYM', 136),
(42, 'CENTRAL AFRICAN REPUBLIC', 'CF', 'CAF', 140),
(43, 'CHAD', 'TD', 'TCD', 148),
(44, 'CHILE', 'CL', 'CHL', 152),
(45, 'CHINA', 'CN', 'CHN', 156),
(46, 'CHRISTMAS ISLAND', 'CX', 'CXR', 162),
(47, 'COCOS (KEELING) ISLANDS', 'CC', 'CCK', 166),
(48, 'COLOMBIA', 'CO', 'COL', 170),
(49, 'COMOROS', 'KM', 'COM', 174),
(50, 'CONGO, Democratic Republic of (was Zaire)', 'CD', 'COD', 180),
(51, 'CONGO, Republic of', 'CG', 'COG', 178),
(52, 'COOK ISLANDS', 'CK', 'COK', 184),
(53, 'COSTA RICA', 'CR', 'CRI', 188),
(54, 'COTE D''IVOIRE', 'CI', 'CIV', 384),
(55, 'CROATIA (local name: Hrvatska)', 'HR', 'HRV', 191),
(56, 'CUBA', 'CU', 'CUB', 192),
(57, 'CYPRUS', 'CY', 'CYP', 196),
(58, 'CZECH REPUBLIC', 'CZ', 'CZE', 203),
(59, 'DENMARK', 'DK', 'DNK', 208),
(60, 'DJIBOUTI', 'DJ', 'DJI', 262),
(61, 'DOMINICA', 'DM', 'DMA', 212),
(62, 'DOMINICAN REPUBLIC', 'DO', 'DOM', 214),
(63, 'ECUADOR', 'EC', 'ECU', 218),
(64, 'EGYPT', 'EG', 'EGY', 818),
(65, 'EL SALVADOR', 'SV', 'SLV', 222),
(66, 'EQUATORIAL GUINEA', 'GQ', 'GNQ', 226),
(67, 'ERITREA', 'ER', 'ERI', 232),
(68, 'ESTONIA', 'EE', 'EST', 233),
(69, 'ETHIOPIA', 'ET', 'ETH', 231),
(70, 'FALKLAND ISLANDS (MALVINAS)', 'FK', 'FLK', 238),
(71, 'FAROE ISLANDS', 'FO', 'FRO', 234),
(72, 'FIJI', 'FJ', 'FJI', 242),
(73, 'FINLAND', 'FI', 'FIN', 246),
(74, 'FRANCE', 'FR', 'FRA', 250),
(75, 'FRENCH GUIANA', 'GF', 'GUF', 254),
(76, 'FRENCH POLYNESIA', 'PF', 'PYF', 258),
(77, 'FRENCH SOUTHERN TERRITORIES', 'TF', 'ATF', 260),
(78, 'GABON', 'GA', 'GAB', 266),
(79, 'GAMBIA', 'GM', 'GMB', 270),
(80, 'GEORGIA', 'GE', 'GEO', 268),
(81, 'GERMANY', 'DE', 'DEU', 276),
(82, 'GHANA', 'GH', 'GHA', 288),
(83, 'GIBRALTAR', 'GI', 'GIB', 292),
(84, 'GREECE', 'GR', 'GRC', 300),
(85, 'GREENLAND', 'GL', 'GRL', 304),
(86, 'GRENADA', 'GD', 'GRD', 308),
(87, 'GUADELOUPE', 'GP', 'GLP', 312),
(88, 'GUAM', 'GU', 'GUM', 316),
(89, 'GUATEMALA', 'GT', 'GTM', 320),
(90, 'GUINEA', 'GN', 'GIN', 324),
(91, 'GUINEA-BISSAU', 'GW', 'GNB', 624),
(92, 'GUYANA', 'GY', 'GUY', 328),
(93, 'HAITI', 'HT', 'HTI', 332),
(94, 'HEARD AND MC DONALD ISLANDS', 'HM', 'HMD', 334),
(95, 'HONDURAS', 'HN', 'HND', 340),
(96, 'HONG KONG', 'HK', 'HKG', 344),
(97, 'HUNGARY', 'HU', 'HUN', 348),
(98, 'ICELAND', 'IS', 'ISL', 352),
(99, 'INDIA', 'IN', 'IND', 356),
(100, 'INDONESIA', 'ID', 'IDN', 360),
(101, 'IRAN (ISLAMIC REPUBLIC OF)', 'IR', 'IRN', 364),
(102, 'IRAQ', 'IQ', 'IRQ', 368),
(103, 'IRELAND', 'IE', 'IRL', 372),
(104, 'ISRAEL', 'IL', 'ISR', 376),
(105, 'ITALY', 'IT', 'ITA', 380),
(106, 'JAMAICA', 'JM', 'JAM', 388),
(107, 'JAPAN', 'JP', 'JPN', 392),
(108, 'JORDAN', 'JO', 'JOR', 400),
(109, 'KAZAKHSTAN', 'KZ', 'KAZ', 398),
(110, 'KENYA', 'KE', 'KEN', 404),
(111, 'KIRIBATI', 'KI', 'KIR', 296),
(112, 'KOREA, DEMOCRATIC PEOPLE''S REPUBLIC OF', 'KP', 'PRK', 408),
(113, 'KOREA, REPUBLIC OF', 'KR', 'KOR', 410),
(114, 'KUWAIT', 'KW', 'KWT', 414),
(115, 'KYRGYZSTAN', 'KG', 'KGZ', 417),
(116, 'LAO PEOPLE''S DEMOCRATIC REPUBLIC', 'LA', 'LAO', 418),
(117, 'LATVIA', 'LV', 'LVA', 428),
(118, 'LEBANON', 'LB', 'LBN', 422),
(119, 'LESOTHO', 'LS', 'LSO', 426),
(120, 'LIBERIA', 'LR', 'LBR', 430),
(121, 'LIBYAN ARAB JAMAHIRIYA', 'LY', 'LBY', 434),
(122, 'LIECHTENSTEIN', 'LI', 'LIE', 438),
(123, 'LITHUANIA', 'LT', 'LTU', 440),
(124, 'LUXEMBOURG', 'LU', 'LUX', 442),
(125, 'MACAU', 'MO', 'MAC', 446),
(126, 'MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF', 'MK', 'MKD', 807),
(127, 'MADAGASCAR', 'MG', 'MDG', 450),
(128, 'MALAWI', 'MW', 'MWI', 454),
(129, 'MALAYSIA', 'MY', 'MYS', 458),
(130, 'MALDIVES', 'MV', 'MDV', 462),
(131, 'MALI', 'ML', 'MLI', 466),
(132, 'MALTA', 'MT', 'MLT', 470),
(133, 'MARSHALL ISLANDS', 'MH', 'MHL', 584),
(134, 'MARTINIQUE', 'MQ', 'MTQ', 474),
(135, 'MAURITANIA', 'MR', 'MRT', 478),
(136, 'MAURITIUS', 'MU', 'MUS', 480),
(137, 'MAYOTTE', 'YT', 'MYT', 175),
(138, 'MEXICO', 'MX', 'MEX', 484),
(139, 'MICRONESIA, FEDERATED STATES OF', 'FM', 'FSM', 583),
(140, 'MOLDOVA, REPUBLIC OF', 'MD', 'MDA', 498),
(141, 'MONACO', 'MC', 'MCO', 492),
(142, 'MONGOLIA', 'MN', 'MNG', 496),
(143, 'MONTSERRAT', 'MS', 'MSR', 500),
(144, 'MOROCCO', 'MA', 'MAR', 504),
(145, 'MOZAMBIQUE', 'MZ', 'MOZ', 508),
(146, 'MYANMAR', 'MM', 'MMR', 104),
(147, 'NAMIBIA', 'NA', 'NAM', 516),
(148, 'NAURU', 'NR', 'NRU', 520),
(149, 'NEPAL', 'NP', 'NPL', 524),
(150, 'NETHERLANDS', 'NL', 'NLD', 528),
(151, 'NETHERLANDS ANTILLES', 'AN', 'ANT', 530),
(152, 'NEW CALEDONIA', 'NC', 'NCL', 540),
(153, 'NEW ZEALAND', 'NZ', 'NZL', 554),
(154, 'NICARAGUA', 'NI', 'NIC', 558),
(155, 'NIGER', 'NE', 'NER', 562),
(156, 'NIGERIA', 'NG', 'NGA', 566),
(157, 'NIUE', 'NU', 'NIU', 570),
(158, 'NORFOLK ISLAND', 'NF', 'NFK', 574),
(159, 'NORTHERN MARIANA ISLANDS', 'MP', 'MNP', 580),
(160, 'NORWAY', 'NO', 'NOR', 578),
(161, 'OMAN', 'OM', 'OMN', 512),
(162, 'PAKISTAN', 'PK', 'PAK', 586),
(163, 'PALAU', 'PW', 'PLW', 585),
(164, 'PALESTINIAN TERRITORY, Occupied', 'PS', 'PSE', 275),
(165, 'PANAMA', 'PA', 'PAN', 591),
(166, 'PAPUA NEW GUINEA', 'PG', 'PNG', 598),
(167, 'PARAGUAY', 'PY', 'PRY', 600),
(168, 'PERU', 'PE', 'PER', 604),
(169, 'PHILIPPINES', 'PH', 'PHL', 608),
(170, 'PITCAIRN', 'PN', 'PCN', 612),
(171, 'POLAND', 'PL', 'POL', 616),
(172, 'PORTUGAL', 'PT', 'PRT', 620),
(173, 'PUERTO RICO', 'PR', 'PRI', 630),
(174, 'QATAR', 'QA', 'QAT', 634),
(175, 'REUNION', 'RE', 'REU', 638),
(176, 'ROMANIA', 'RO', 'ROU', 642),
(177, 'RUSSIAN FEDERATION', 'RU', 'RUS', 643),
(178, 'RWANDA', 'RW', 'RWA', 646),
(179, 'SAINT HELENA', 'SH', 'SHN', 654),
(180, 'SAINT KITTS AND NEVIS', 'KN', 'KNA', 659),
(181, 'SAINT LUCIA', 'LC', 'LCA', 662),
(182, 'SAINT PIERRE AND MIQUELON', 'PM', 'SPM', 666),
(183, 'SAINT VINCENT AND THE GRENADINES', 'VC', 'VCT', 670),
(184, 'SAMOA', 'WS', 'WSM', 882),
(185, 'SAN MARINO', 'SM', 'SMR', 674),
(186, 'SAO TOME AND PRINCIPE', 'ST', 'STP', 678),
(187, 'SAUDI ARABIA', 'SA', 'SAU', 682),
(188, 'SENEGAL', 'SN', 'SEN', 686),
(189, 'SERBIA AND MONTENEGRO', 'CS', 'SCG', 891),
(190, 'SEYCHELLES', 'SC', 'SYC', 690),
(191, 'SIERRA LEONE', 'SL', 'SLE', 694),
(192, 'SINGAPORE', 'SG', 'SGP', 702),
(193, 'SLOVAKIA', 'SK', 'SVK', 703),
(194, 'SLOVENIA', 'SI', 'SVN', 705),
(195, 'SOLOMON ISLANDS', 'SB', 'SLB', 90),
(196, 'SOMALIA', 'SO', 'SOM', 706),
(197, 'SOUTH AFRICA', 'ZA', 'ZAF', 710),
(198, 'SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS', 'GS', 'SGS', 239),
(199, 'SPAIN', 'ES', 'ESP', 724),
(200, 'SRI LANKA', 'LK', 'LKA', 144),
(201, 'SUDAN', 'SD', 'SDN', 736),
(202, 'SURINAME', 'SR', 'SUR', 740),
(203, 'SVALBARD AND JAN MAYEN ISLANDS', 'SJ', 'SJM', 744),
(204, 'SWAZILAND', 'SZ', 'SWZ', 748),
(205, 'SWEDEN', 'SE', 'SWE', 752),
(206, 'SWITZERLAND', 'CH', 'CHE', 756),
(207, 'SYRIAN ARAB REPUBLIC', 'SY', 'SYR', 760),
(208, 'TAIWAN', 'TW', 'TWN', 158),
(209, 'TAJIKISTAN', 'TJ', 'TJK', 762),
(210, 'TANZANIA, UNITED REPUBLIC OF', 'TZ', 'TZA', 834),
(211, 'THAILAND', 'TH', 'THA', 764),
(212, 'TIMOR-LESTE', 'TL', 'TLS', 626),
(213, 'TOGO', 'TG', 'TGO', 768),
(214, 'TOKELAU', 'TK', 'TKL', 772),
(215, 'TONGA', 'TO', 'TON', 776),
(216, 'TRINIDAD AND TOBAGO', 'TT', 'TTO', 780),
(217, 'TUNISIA', 'TN', 'TUN', 788),
(218, 'TURKEY', 'TR', 'TUR', 792),
(219, 'TURKMENISTAN', 'TM', 'TKM', 795),
(220, 'TURKS AND CAICOS ISLANDS', 'TC', 'TCA', 796),
(221, 'TUVALU', 'TV', 'TUV', 798),
(222, 'UGANDA', 'UG', 'UGA', 800),
(223, 'UKRAINE', 'UA', 'UKR', 804),
(224, 'UNITED ARAB EMIRATES', 'AE', 'ARE', 784),
(225, 'UNITED KINGDOM', 'GB', 'GBR', 826),
(226, 'UNITED STATES', 'US', 'USA', 840),
(227, 'UNITED STATES MINOR OUTLYING ISLANDS', 'UM', 'UMI', 581),
(228, 'URUGUAY', 'UY', 'URY', 858),
(229, 'UZBEKISTAN', 'UZ', 'UZB', 860),
(230, 'VANUATU', 'VU', 'VUT', 548),
(231, 'VATICAN CITY STATE (HOLY SEE)', 'VA', 'VAT', 336),
(232, 'VENEZUELA', 'VE', 'VEN', 862),
(233, 'VIET NAM', 'VN', 'VNM', 704),
(234, 'VIRGIN ISLANDS (BRITISH)', 'VG', 'VGB', 92),
(235, 'VIRGIN ISLANDS (U.S.)', 'VI', 'VIR', 850),
(236, 'WALLIS AND FUTUNA ISLANDS', 'WF', 'WLF', 876),
(237, 'WESTERN SAHARA', 'EH', 'ESH', 732),
(238, 'YEMEN', 'YE', 'YEM', 887),
(239, 'ZAMBIA', 'ZM', 'ZMB', 894),
(240, 'ZIMBABWE', 'ZW', 'ZWE', 716);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
